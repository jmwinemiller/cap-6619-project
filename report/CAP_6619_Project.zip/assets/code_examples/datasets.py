from genomic_benchmarks.data_check import list_datasets

list_datasets()
