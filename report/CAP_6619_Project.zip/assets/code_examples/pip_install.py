# PIP Package Installation
!pip install -q mermaid-py
!pip install -q genomic-benchmarks
!pip install -q jupyter_capture_output
